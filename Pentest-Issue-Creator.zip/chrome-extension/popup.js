// Dữ liệu vulnerabilities từ Cloudflare Host
let vulnerabilities = [];
let selectedVulnerability = null;

// Configuration
const DEFAULT_HOST_URL = 'https://pentest-issue-creator.ncv.workers.dev/vuln?private=2ysY2PmZ9AgrIu50VDRkRq5SztFJd0lv';
const STORAGE_KEYS = {
  HOST_URL: 'pentest_HOST_URL'
};

// Lấy cấu hình từ Chrome Storage
async function getStoredConfig() {
  try {
    const result = await chrome.storage.local.get([STORAGE_KEYS.HOST_URL]);
    return {
      hostUrl: result[STORAGE_KEYS.HOST_URL] || DEFAULT_HOST_URL
    };
  } catch (error) {
    console.error('Error getting stored config:', error);
    return { hostUrl: DEFAULT_HOST_URL };
  }
}

// Lưu cấu hình vào Chrome Storage
async function saveConfig(hostUrl) {
  try {
    await chrome.storage.local.set({
      [STORAGE_KEYS.HOST_URL]: hostUrl
    });
    return true;
  } catch (error) {
    console.error('Error saving config:', error);
    return false;
  }
}

// Load dữ liệu vulnerabilities từ Cloudflare Host
async function loadVulnerabilities(showStatus = false) {
  try {
    if (showStatus) {
      updateStatus('Đang tải dữ liệu...');
    }
    
    const config = await getStoredConfig();
    
    const headers = {
      'Content-Type': 'application/json'
    };

    const response = await fetch(config.hostUrl, {
      method: 'GET',
      headers,
      cache: 'no-cache'
    });
    
    // If host returns 401, surface message but do not force modal.
    if (response.status === 401) {
      if (showStatus) {
        updateStatus('Lỗi xác thực (401) khi kết nối tới host');
      }
      return false;
    }
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.message || 'API Error');
    }
    
    vulnerabilities = data;
    console.log('Đã load vulnerabilities từ Cloudflare Host:', vulnerabilities.length);
    
    if (showStatus) {
      updateStatus(`Đã tải ${vulnerabilities.length} loại lỗi`);
      setTimeout(() => updateStatus(''), 2000);
    }
    
    return true;
  } catch (error) {
    console.error('Lỗi khi load từ Host:', error);
    if (showStatus) {
      updateStatus(`Lỗi: ${error.message}`);
    }
    return false;
  }
}


function showKeyModal() {
  const modal = document.getElementById('keyModal');
  const hostUrlInput = document.getElementById('hostUrlInput');
  
  // Load current config
  getStoredConfig().then(config => {
    hostUrlInput.value = config.hostUrl;
  });
  
  // Use flex so modal centers and allows scrolling inside the popup
  modal.style.display = 'flex';
  // Slight delay to ensure element is visible before focusing
  setTimeout(() => hostUrlInput.focus(), 50);
}

// Ẩn modal
function hideKeyModal() {
  const modal = document.getElementById('keyModal');
  modal.style.display = 'none';
}

// Cập nhật status message
function updateStatus(message) {
  const statusEl = document.getElementById('status');
  if (statusEl) {
    statusEl.textContent = message;
  }
}

// Cập nhật preview content
function updatePreview(vuln) {
  if (!vuln) {
    hidePreview();
    return;
  }

  // Cập nhật tên issue trong header
  const header = document.querySelector('.preview-section h4');
  if (header) {
    header.textContent = vuln.name || 'UNNAMED';
  }

  // Cập nhật nội dung preview
  const previewDescription = document.getElementById('previewDescription');
  const previewImpact = document.getElementById('previewImpact');
  const previewReproduce = document.getElementById('previewReproduce');
  const previewSolution = document.getElementById('previewSolution');
  const previewNote = document.getElementById('previewNote');

  if (previewDescription) previewDescription.textContent = vuln.desc || vuln.description || 'Không có mô tả';
  if (previewImpact) previewImpact.textContent = vuln.impact || 'Không có thông tin tác động';
  if (previewReproduce) previewReproduce.textContent = vuln.reprod || vuln.reproduce || 'Không có hướng dẫn tái hiện';
  if (previewSolution) previewSolution.textContent = vuln.solution || 'Không có giải pháp';
  if (previewNote) previewNote.textContent = vuln.note || 'Không có ghi chú';

  // Hiển thị nút preview toggle
  document.getElementById('previewToggle').style.display = 'inline-block';
}

// Hiển thị preview
function showPreview() {
  document.getElementById('previewSection').style.display = 'block';
  document.getElementById('previewToggle').textContent = 'Ẩn preview';
}

// Ẩn preview
function hidePreview() {
  document.getElementById('previewSection').style.display = 'none';
  document.getElementById('previewToggle').textContent = 'Xem trước nội dung issue';
}

// Toggle preview visibility
function togglePreview() {
  const previewSection = document.getElementById('previewSection');
  if (previewSection.style.display === 'none' || !previewSection.style.display) {
    showPreview();
  } else {
    hidePreview();
  }
}

// Copy content to clipboard
function copyToClipboard(elementId, button) {
  const element = document.getElementById(elementId);
  if (!element) return;
  
  const text = element.textContent;
  
  // Use the Clipboard API if available
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => {
      showCopyFeedback(button);
    }).catch(err => {
      console.error('Failed to copy: ', err);
      fallbackCopy(text, button);
    });
  } else {
    fallbackCopy(text, button);
  }
}

// Show copy success feedback
function showCopyFeedback(element) {
  // Add copying class for smooth animation
  element.classList.add('copying');
  
  // Store original text
  const originalText = element.textContent;
  
  // Show success message
  const fieldName = originalText.split(':')[0];
  element.textContent = `${fieldName}: ✓ Đã copy!`;
  
  // Reset after animation
  setTimeout(() => {
    element.textContent = originalText;
    element.classList.remove('copying');
  }, 1500);
}

// Fallback copy method for older browsers
function fallbackCopy(text, button) {
  const textArea = document.createElement('textarea');
  textArea.value = text;
  textArea.style.position = 'fixed';
  textArea.style.opacity = '0';
  document.body.appendChild(textArea);
  textArea.select();
  
  try {
    document.execCommand('copy');
    showCopyFeedback(button);
  } catch (err) {
    console.error('Fallback copy failed: ', err);
  }
  
  document.body.removeChild(textArea);
}

// Tạo display text cho vulnerability
function createVulnerabilityDisplayText(vuln) {
  let path = vuln.category;
  if (vuln.subcategory) {
    path += '/' + vuln.subcategory;
  }
  if (vuln.variant) {
    path += '/' + vuln.variant;
  }
  return {
    path: path,
    name: vuln.name
  };
}

// Hiển thị dropdown list với hierarchy
function showDropdownList(filteredVulns) {
  const dropdownList = document.getElementById('dropdownList');
  dropdownList.innerHTML = '';
  
  if (filteredVulns.length === 0) {
    dropdownList.style.display = 'none';
    return;
  }
  
  // Nhóm vulnerabilities theo hierarchy
  const grouped = {};
  
  filteredVulns.forEach((vuln, index) => {
    const category = vuln.category || 'Other';
    const subcategory = vuln.subcategory || '';
    const variant = vuln.variant || '';
    
    if (!grouped[category]) {
      grouped[category] = {};
    }
    
    if (!grouped[category][subcategory]) {
      grouped[category][subcategory] = {};
    }
    
    if (!grouped[category][subcategory][variant]) {
      grouped[category][subcategory][variant] = [];
    }
    
    grouped[category][subcategory][variant].push({
      vuln: vuln,
      originalIndex: index
    });
  });
  
  // Render hierarchy
  Object.keys(grouped).sort().forEach(category => {
    // Category header
    const categoryItem = document.createElement('div');
    categoryItem.className = 'dropdown-category';
    categoryItem.textContent = category;
    dropdownList.appendChild(categoryItem);
    
    Object.keys(grouped[category]).sort().forEach(subcategory => {
      if (subcategory) {
        // Subcategory header
        const subcategoryItem = document.createElement('div');
        subcategoryItem.className = 'dropdown-subcategory';
        subcategoryItem.textContent = subcategory;
        dropdownList.appendChild(subcategoryItem);
      }
      
      Object.keys(grouped[category][subcategory]).sort().forEach(variant => {
        if (variant) {
          // Variant header
          const variantItem = document.createElement('div');
          variantItem.className = 'dropdown-variant';
          variantItem.textContent = variant;
          dropdownList.appendChild(variantItem);
        }
        
        // Vulnerability items
        grouped[category][subcategory][variant].forEach(item => {
          const vulnItem = document.createElement('div');
          vulnItem.className = 'dropdown-item';
          vulnItem.dataset.index = item.originalIndex;
          
          let indentClass = 'dropdown-item';
          if (variant) {
            indentClass += ' indent-3';
          } else if (subcategory) {
            indentClass += ' indent-2';
          } else {
            indentClass += ' indent-1';
          }
          vulnItem.className = indentClass;
          
          vulnItem.innerHTML = `<div class="vulnerability-name">${item.vuln.name}</div>`;
          
          vulnItem.addEventListener('click', () => {
            selectVulnerability(item.vuln);
          });
          
          dropdownList.appendChild(vulnItem);
        });
      });
    });
  });
  
  dropdownList.style.display = 'block';
}

// Chọn vulnerability
function selectVulnerability(vuln) {
  selectedVulnerability = vuln;
  const display = createVulnerabilityDisplayText(vuln);
  const input = document.getElementById('vulnerabilitySelect');
  input.value = `${display.path} - ${display.name}`;
  
  // Ẩn dropdown
  document.getElementById('dropdownList').style.display = 'none';
  
  // Cập nhật preview
  updatePreview(vuln);
}

// Filter vulnerabilities theo search term
function filterVulnerabilities(searchTerm) {
  let filtered;
  
  if (!searchTerm.trim()) {
    filtered = vulnerabilities.slice(); // Lấy tất cả items
  } else {
    const term = searchTerm.toLowerCase();
    filtered = vulnerabilities.filter(vuln => {
      return (vuln.category && vuln.category.toLowerCase().includes(term)) ||
             (vuln.subcategory && vuln.subcategory.toLowerCase().includes(term)) ||
             (vuln.variant && vuln.variant.toLowerCase().includes(term)) ||
             (vuln.name && vuln.name.toLowerCase().includes(term));
    });
  }
  
  // Sort theo category, subcategory, variant, name
  filtered.sort((a, b) => {
    // So sánh category trước
    const categoryCompare = (a.category || '').localeCompare(b.category || '');
    if (categoryCompare !== 0) return categoryCompare;
    
    // Nếu category giống nhau, so sánh subcategory
    const aSubcategory = a.subcategory || '';
    const bSubcategory = b.subcategory || '';
    const subcategoryCompare = aSubcategory.localeCompare(bSubcategory);
    if (subcategoryCompare !== 0) return subcategoryCompare;
    
    // Nếu subcategory giống nhau, so sánh variant
    const aVariant = a.variant || '';
    const bVariant = b.variant || '';
    const variantCompare = aVariant.localeCompare(bVariant);
    if (variantCompare !== 0) return variantCompare;
    
    // Cuối cùng so sánh name
    return (a.name || '').localeCompare(b.name || '');
  });
  
  return filtered.slice(0, 50); // Giới hạn 20 kết quả
}

// Hàm để lấy tab hiện tại
async function getCurrentTab() {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// Hàm để trích xuất ID dự án từ URL
function extractProjectId(url) {
  try {
    const match = url.match(/https:\/\/pentest\.viettelcyber\.com\/#\/projects\/(\d+)/);
    if (match && match[1]) {
      return match[1];
    }
  } catch (e) {
    console.error("Không thể phân tích URL:", e);
  }
  return null;
}

// Hàm để lấy token từ localStorage của trang
async function getTokenFromStorage(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: () => {
        return localStorage.getItem('token');
      }
    });
    if (results && results[0]) {
      return results[0].result;
    }
  } catch (e) {
    console.error("Không thể lấy token:", e);
    return null;
  }
}

// Hàm để lấy refresh token từ localStorage của trang
async function getRefreshTokenFromStorage(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: () => {
        return localStorage.getItem('refresh-token');
      }
    });
    if (results && results[0]) {
      return results[0].result;
    }
  } catch (e) {
    console.error("Không thể lấy refresh token:", e);
    return null;
  }
}

// Hàm để cập nhật token trong localStorage của trang
async function updateTokenInStorage(tabId, newToken) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: (token) => {
        localStorage.setItem('token', token);
        return true;
      },
      args: [newToken]
    });
    return results && results[0] && results[0].result;
  } catch (e) {
    console.error("Không thể cập nhật token:", e);
    return false;
  }
}

// Hàm để refresh token
async function refreshToken(tabId) {
  try {
    updateStatus('Đang làm mới token...');
    
    const refreshTokenValue = await getRefreshTokenFromStorage(tabId);
    if (!refreshTokenValue) {
      throw new Error('Không tìm thấy refresh token');
    }

    const response = await fetch('https://pentest.viettelcyber.com/api/v1/token/refresh', {
      method: 'POST',
      headers: {
        'accept': 'application/json',
        'accept-language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/json',
        'origin': 'https://pentest.viettelcyber.com',
        'priority': 'u=1, i',
        'referer': 'https://pentest.viettelcyber.com/',
        'sec-ch-ua': '"Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36'
      },
      body: JSON.stringify({
        token: refreshTokenValue
      })
    });

    if (!response.ok) {
      throw new Error(`Lỗi refresh token: ${response.status}`);
    }

    const result = await response.json();
    
    if (!result.token) {
      throw new Error('Không nhận được token mới từ API refresh');
    }

    // Cập nhật token mới vào localStorage
    const updated = await updateTokenInStorage(tabId, result.token);
    if (!updated) {
      throw new Error('Không thể cập nhật token mới vào localStorage');
    }

    updateStatus('Token đã được làm mới thành công');
    return result.token;

  } catch (error) {
    console.error('Lỗi khi refresh token:', error);
    updateStatus(`Lỗi refresh token: ${error.message}`);
    throw error;
  }
}

// Helper function to make API request with proper headers and retry logic
async function makeApiRequest(url, options, tabId, retryCount = 0) {
  const maxRetries = 1;
  
  try {
    // Lấy token hiện tại
    const token = await getTokenFromStorage(tabId);
    if (!token) {
      await refreshToken(tabId);
      return await makeApiRequest(url, options, tabId, retryCount + 1);
    }

    // Prepare headers
    const headers = {
      'accept': 'application/json',
      'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
      'content-type': 'application/json',
      'priority': 'u=1, i',
      'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'token': token,
      ...options.headers
    };

    // Gửi request
    const response = await fetch(url, {
      ...options,
      headers,
      referrer: 'https://pentest.viettelcyber.com/',
      mode: 'cors',
      credentials: 'omit'
    });

    // Nếu 401 và chưa thử lại, refresh token và đệ quy
    if (response.status === 401 && retryCount < maxRetries) {
      updateStatus('Token hết hạn, đang làm mới...');
      
      // Refresh token
      await refreshToken(tabId);
      
      // Đệ quy gọi lại với retryCount tăng
      updateStatus('Đang gửi request với token mới...');
      return await makeApiRequest(url, options, tabId, retryCount + 1);
    }

    // Nếu vẫn 401 sau khi thử lại
    if (response.status === 401) {
      throw new Error('Token mới vẫn không hợp lệ. Vui lòng đăng nhập lại.');
    }

    // Kiểm tra các lỗi HTTP khác
    if (!response.ok) {
      throw new Error(`Lỗi HTTP: ${response.status}`);
    }

    return await response.json();

  } catch (error) {
    // Nếu là lỗi network và chưa thử lại, có thể thử lại
    if (retryCount < maxRetries && (error.message.includes('fetch') || error.message.includes('network'))) {
      updateStatus('Lỗi kết nối, đang thử lại...');
      return await makeApiRequest(url, options, tabId, retryCount + 1);
    }
    
    throw error;
  }
}

// Hàm tạo issue với 2 bước: POST để tạo và PUT để cập nhật
async function createIssueWithTwoSteps(tabId, projectId, vulnerabilityData) {
  try {
    updateStatus('Đang tạo issue...');
    
    // Bước 1: POST để tạo issue với content trống
    const createData = {
      projectId: parseInt(projectId, 10),
      category: vulnerabilityData.category,
      subcategory: vulnerabilityData.subcategory || null,
      variant: vulnerabilityData.variant || null,
      severity: "VARIES",
      cvss: "",
      content: [{
        name: "UNNAMED",
        language: "VIETNAM",
        description: "",
        reproduce: "",
        solution: ""
      }]
    };

    const createResponse = await makeApiRequest(
      'https://pentest.viettelcyber.com/api/issue',
      {
        method: 'POST',
        body: JSON.stringify(createData)
      },
      tabId
    );

    if (!createResponse || !createResponse.id) {
      throw new Error('Không nhận được ID issue từ server');
    }

    const issueId = createResponse.id;
    updateStatus('Issue đã tạo, đang cập nhật nội dung...');

    // Bước 2: Gửi nhiều PUT request song song cho từng field
    const fieldsToUpdate = [
      { name: vulnerabilityData.name || "UNNAMED", language: "VIETNAM" },
      { description: vulnerabilityData.desc || vulnerabilityData.description || "", language: "VIETNAM" },
      { impact: vulnerabilityData.impact || "", language: "VIETNAM" },
      { reproduce: vulnerabilityData.reprod || vulnerabilityData.reproduce || "", language: "VIETNAM" },
      { solution: vulnerabilityData.solution || "", language: "VIETNAM" },
      { note: vulnerabilityData.note || "", language: "VIETNAM" }
    ];

    // Gửi tất cả PUT request song song
    const updatePromises = fieldsToUpdate.map(fieldData => 
      makeApiRequest(
        `https://pentest.viettelcyber.com/api/issue/${issueId}`,
        {
          method: 'PUT',
          body: JSON.stringify(fieldData)
        },
        tabId
      )
    );

    // Đợi tất cả request hoàn thành
    await Promise.all(updatePromises);

    updateStatus('Issue đã được tạo và cập nhật thành công!');
    return createResponse;

  } catch (error) {
    console.error('Lỗi khi tạo issue:', error);
    throw error;
  }
}

// Xử lý nhấp chuột vào nút
document.getElementById('sendRequestBtn').addEventListener('click', async () => {
  const button = document.getElementById('sendRequestBtn');
  
  // Kiểm tra xem đã chọn vulnerability chưa
  if (!selectedVulnerability) {
    updateStatus('Vui lòng chọn loại lỗi trước khi tạo issue.');
    return;
  }
  
  button.disabled = true;
  updateStatus('Đang xử lý...');

  const tab = await getCurrentTab();

  if (!tab || !tab.url || !tab.id) {
    updateStatus('Lỗi: Không tìm thấy tab hoạt động.');
    button.disabled = false;
    return;
  }

  // 1. Lấy Project ID từ URL
  const projectId = extractProjectId(tab.url);
  if (!projectId) {
    updateStatus('Lỗi: Không tìm thấy Project ID trong URL.');
    button.disabled = false;
    return;
  }

  // 2. Lấy Token từ Local Storage
  let token = await getTokenFromStorage(tab.id);
  if (!token) {
    updateStatus('Lỗi: Không tìm thấy token trong localStorage.');
    await refreshToken(tab.id);
  }

  try {
    // Gửi request với 2 bước: tạo issue rồi cập nhật nội dung
    const result = await createIssueWithTwoSteps(tab.id, projectId, selectedVulnerability);
    
    updateStatus('Thành công! Đang chuyển hướng...');
    console.log('Phản hồi API:', result);

    // Lấy issueId từ response và redirect
    if (result && result.id) {
      const issueId = result.id;
      const redirectUrl = `https://pentest.viettelcyber.com/#/projects/${projectId}/issues/${issueId}`;
      
      // Redirect tab hiện tại đến URL mới
      await chrome.tabs.update(tab.id, { url: redirectUrl });
      
      // Đóng popup sau khi redirect
      window.close();
    }

  } catch (error) {
    console.log('Lỗi khi gửi yêu cầu:', error);
    updateStatus(`Lỗi: ${error.message}`);
  } finally {
    button.disabled = false;
  }
});

// Khởi tạo khi DOM được load
document.addEventListener('DOMContentLoaded', async () => {
  // Load dữ liệu từ Cloudflare Host khi khởi động
  const success = await loadVulnerabilities();
  
  const input = document.getElementById('vulnerabilitySelect');
  const dropdownList = document.getElementById('dropdownList');
  const refreshBtn = document.getElementById('refreshDataBtn');
  const settingsBtn = document.getElementById('settingsBtn');
  const previewToggle = document.getElementById('previewToggle');
  const modal = document.getElementById('keyModal');
  const saveKeyBtn = document.getElementById('saveKeyBtn');
  const cancelKeyBtn = document.getElementById('cancelKeyBtn');
  const hostUrlInput = document.getElementById('hostUrlInput');
  
  // Xử lý preview toggle
  previewToggle.addEventListener('click', () => {
    togglePreview();
  });
  
  // Xử lý copy buttons với event delegation
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('copy-btn') || e.target.hasAttribute('data-target')) {
      const targetId = e.target.getAttribute('data-target');
      if (targetId) {
        copyToClipboard(targetId, e.target);
      }
    }
  });
  
  // Nếu không load được dữ liệu, hiển thị modal
  if (!success) {
    showKeyModal();
  }
  
  // Xử lý button settings
  settingsBtn.addEventListener('click', () => {
    showKeyModal();
  });
  
  // Xử lý modal lưu Host URL
  saveKeyBtn.addEventListener('click', async () => {
    const hostUrl = hostUrlInput.value.trim() || DEFAULT_HOST_URL;

    saveKeyBtn.disabled = true;
    saveKeyBtn.textContent = 'Đang lưu...';

    // Lưu config
    const saved = await saveConfig(hostUrl);
    if (!saved) {
      updateStatus('Lỗi khi lưu cấu hình');
      saveKeyBtn.disabled = false;
      saveKeyBtn.textContent = 'Lưu';
      return;
    }

    // Test connection
    const testSuccess = await loadVulnerabilities(true);

    saveKeyBtn.disabled = false;
    saveKeyBtn.textContent = 'Lưu';

    if (testSuccess) {
      hideKeyModal();
      // Clear dropdown và input
      input.value = '';
      selectedVulnerability = null;
      dropdownList.style.display = 'none';
    }
  });
  
  cancelKeyBtn.addEventListener('click', () => {
    hideKeyModal();
  });
  
  // Đóng modal khi click outside
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      hideKeyModal();
    }
  });
  
  
  hostUrlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      saveKeyBtn.click();
    }
  });
  
  // Xử lý button refresh
  refreshBtn.addEventListener('click', async () => {
    refreshBtn.disabled = true;
    refreshBtn.textContent = '🔄 Đang tải...';
    
    const success = await loadVulnerabilities(true);
    
    refreshBtn.disabled = false;
    refreshBtn.textContent = '🔄';
    
    // Clear dropdown và input nếu load thành công
    if (success) {
      input.value = '';
      selectedVulnerability = null;
      dropdownList.style.display = 'none';
    }
  });
  
  // Xử lý focus vào input
  input.addEventListener('focus', () => {
    const filtered = filterVulnerabilities(input.value);
    showDropdownList(filtered);
  });
  
  // Xử lý input search
  input.addEventListener('input', (e) => {
    const searchTerm = e.target.value;
    const filtered = filterVulnerabilities(searchTerm);
    showDropdownList(filtered);
  });
  
  // Xử lý click outside để ẩn dropdown
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.dropdown-container')) {
      dropdownList.style.display = 'none';
    }
  });
  
  // Xử lý keyboard navigation
  input.addEventListener('keydown', (e) => {
    // Chỉ lấy các dropdown-item thực sự (có dataset.index), không lấy headers
    const items = dropdownList.querySelectorAll('.dropdown-item[data-index]');
    let selectedIndex = Array.from(items).findIndex(item => item.classList.contains('selected'));
    
    switch(e.key) {
      case 'ArrowDown':
        e.preventDefault();
        if (selectedIndex < items.length - 1) {
          if (selectedIndex >= 0) items[selectedIndex].classList.remove('selected');
          items[selectedIndex + 1].classList.add('selected');
        } else if (items.length > 0) {
          if (selectedIndex >= 0) items[selectedIndex].classList.remove('selected');
          items[0].classList.add('selected');
        }
        break;
        
      case 'ArrowUp':
        e.preventDefault();
        if (selectedIndex > 0) {
          items[selectedIndex].classList.remove('selected');
          items[selectedIndex - 1].classList.add('selected');
        } else if (items.length > 0) {
          if (selectedIndex >= 0) items[selectedIndex].classList.remove('selected');
          items[items.length - 1].classList.add('selected');
        }
        break;
        
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && items[selectedIndex]) {
          const vulnIndex = parseInt(items[selectedIndex].dataset.index);
          const filtered = filterVulnerabilities(input.value);
          if (filtered[vulnIndex]) {
            selectVulnerability(filtered[vulnIndex]);
          }
        }
        break;
        
      case 'Escape':
        dropdownList.style.display = 'none';
        input.blur();
        break;
    }
  });
});
